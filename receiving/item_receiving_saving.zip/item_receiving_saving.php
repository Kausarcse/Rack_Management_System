<?php
session_start();
include('../db_connection_class.php');
$obj = new DB_Connection_Class_Main();
$obj->connection();

//print_r($_POST);
//exit;

$data_previously_saved = "No";
$data_insertion_hampering = "No";
$on_hand_quantity_update = "No";

$recording_person_id = 'hriday';
$recording_person_name = 'Hriday';

/*
$user_id = $_SESSION['user_id'];
$password = $_SESSION['password'];

$sql = "select * from hrm_info.user_login where user_id='$user_id' and `password`='$password'";
$result = mysqli_query($con,$sql) or die(mysqli_error($con));

if( mysqli_num_rows($result) < 1 )
{

	header('Location:logout.php');

}
else
{
	while($row=mysqli_fetch_array($result))
	{	
		 $user_name=$row['user_name'];	
	}
}

*/

$receiving_location= $_POST['receiving_location'];
$received_by= $_POST['received_by'];
$date_of_receipt= $_POST['date_of_receipt'];
$splitted_date_of_receipt= explode("/",$date_of_receipt);
$date_of_receipt= $splitted_date_of_receipt[2]."-".$splitted_date_of_receipt[1]."-".$splitted_date_of_receipt[0];
$roll_no= $_POST['roll_no'];
$pp_number= $_POST['pp_number'];
$work_order_number= $_POST['work_order_number'];
$customer_name= $_POST['customer_name'];
$shade= $_POST['shade'];
$construction= $_POST['construction'];
$composition= $_POST['composition'];
$weave= $_POST['weave'];
$length= $_POST['length'];
$finished_width= $_POST['finished_width'];
$finished_type= $_POST['finished_type'];
$row_number= $_POST['row_number'];
$rack_number= $_POST['rack_number'];
$rack_hole_number= $_POST['rack_hole_number'];
$bin_card_number= $_POST['bin_card_number'];
$quantiy= $_POST['quantiy'];
$uom= $_POST['uom'];

$barcode_code = $_POST['barcode_code'];

mysqli_query($con,"BEGIN");
mysqli_query($con,"START TRANSACTION") or die(mysqli_error($con));

$select_sql_for_duplicacy="select * from `item_receiving` where `barcode_code` = '$barcode_code' ";

// $select_sql_for_duplicacy="select * from `item_receiving` where `pp_number`='$pp_number' and `work_order_number`='$work_order_number' and `customer_name`='$customer_name' and `shade`='$shade' and `construction`='$construction' and `composition`='$composition' and `weave`='$weave' and `length`='$length' and `finished_width`='$finished_width' and `finished_type`='$finished_type'";

// $select_sql_for_duplicacy="select * from `item_receiving` where `shade`='$shade' and `construction`='$construction' and `composition`='$composition' and `weave`='$weave' and `length`='$length' and `finished_width`='$finished_width' and `finished_type`='$finished_type'";

$result = mysqli_query($con,$select_sql_for_duplicacy) or die(mysqli_error($con));

if(mysqli_num_rows($result)>0)
{

	$data_previously_saved="Yes";

}

else if(mysqli_num_rows($result) < 1)
{
	$insert_sql_statement="insert into `item_receiving` ( `barcode_code`,`receiving_location`,`received_by`,`date_of_receipt`,`roll_no`,`pp_number`,`work_order_number`,`customer_name`,`shade`,`construction`,`composition`,`weave`,`length`,`finished_width`,`finished_type`,`row_number`,`rack_number`,`rack_hole_number`,`bin_card_number`,`quantiy`,`uom`,`recording_person_id`,`recording_person_name`,`recording_time` ) values ('$barcode_code','$receiving_location','$received_by','$date_of_receipt','$roll_no','$pp_number','$work_order_number','$customer_name','$shade','$construction','$composition','$weave','$length','$finished_width','$finished_type',$row_number,$rack_number,$rack_hole_number,'$bin_card_number','$quantiy','$uom','$recording_person_id','$recording_person_name',NOW())";

	mysqli_query($con, $insert_sql_statement) or die(mysqli_error($con));

	if(mysqli_affected_rows($con)<>1)
	{
	
		$data_insertion_hampering = "Yes";
	
	}


	//for on hand quantity add

	$select_sql_for_duplicacy3 ="select * from `item_info` where `shade`='$shade' and `construction`='$construction' and `composition`='$composition' and `weave`='$weave' and `finished_width`='$finished_width' and `finished_type`='$finished_type'";

	$result = mysqli_query($con, $select_sql_for_duplicacy3) or die(mysqli_error($con));

	if(mysqli_num_rows($result) < 1)
	{

		$insert_sql_statement3="insert into `item_info` ( `shade`,`construction`,`composition`,`weave`,`finished_width`,`finished_type`,`on_hand_stock`, `uom`,`total_roll`,`recording_person_id`,`recording_person_name`,`recording_time` ) values ('$shade','$construction','$composition','$weave','$finished_width','$finished_type', '$length', 'yds', '1','$recording_person_id','$recording_person_name',NOW())";

		mysqli_query($con,$insert_sql_statement3) or die(mysqli_error($con));

		if(mysqli_affected_rows($con)<>1)
		{
		
			$data_insertion_hampering = "Yes";
		
		}

	}
	else 
	{
		$row = mysqli_fetch_array($result);
		$previous_on_hand_stock = $row['on_hand_stock'];
		$total_number_of_roll = $row['total_roll'] + 1;
		$new_on_hand_stock = $previous_on_hand_stock + $length;

		$update_sql_statement="UPDATE item_info
								SET on_hand_stock = '$new_on_hand_stock',
									total_roll = '$total_number_of_roll'
								WHERE shade = '$shade'
								  AND construction = '$construction'
								  AND composition = '$composition'
								  AND weave = '$weave'
								  AND finished_width = '$finished_width'
								  AND finished_type = '$finished_type'
							;";

		mysqli_query($con,$update_sql_statement) or die(mysqli_error($con));

		if(mysqli_affected_rows($con)<>1)
		{
		
			$data_insertion_hampering = "Yes";
		
		}
	}
}


//for item creation 

// $select_sql_for_duplicacy_2 = "select * from `item_creation` where `shade`='$shade' and `construction`='$construction' and `composition`='$composition' and `weave`='$weave' and `finished_width`='$finished_width' and `finished_type`='$finished_type'";

// $result = mysqli_query($con, $select_sql_for_duplicacy_2) or die(mysqli_error($con));

// if(mysqli_num_rows($result)>0)
// {

// 	$data_previously_saved="Yes";

// }
// else if(mysqli_num_rows($result) < 1)
// {

// 	$insert_sql_statement2="insert into `item_creation` ( `shade`,`construction`,`composition`,`weave`,`finished_width`,`finished_type`,`recording_person_id`,`recording_person_name`,`recording_time` ) values ('$shade','$construction','$composition','$weave','$finished_width','$finished_type','$recording_person_id','$recording_person_name',NOW())";

// 	mysqli_query($con, $insert_sql_statement2) or die(mysqli_error($con));

// 	if(mysqli_affected_rows($con)<>1)
// 	{
	
// 		$data_insertion_hampering = "Yes";
// 	}
// }



// mysqli_query($con,"COMMIT");
// echo "Data is successfully saved.";


if($data_previously_saved == "Yes")
{

	mysqli_query($con,"ROLLBACK");
	echo "Data is previously saved.";

}
else if($data_insertion_hampering == "No" )
{

 	mysqli_query($con,"COMMIT");
 	echo "Data is successfully saved. ";

}
else if($on_hand_quantity_update == "Yes" )
{

 	mysqli_query($con,"COMMIT");
 	echo "On hand quantity updated. ";

}
else
{

	mysqli_query($con,"ROLLBACK");
	echo "Data is not successfully saved.";

}

$obj->disconnection();

?>
